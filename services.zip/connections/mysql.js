function newConnection(){
    var mysql = require('mysql');
    var dbconnection = mysql.createPool({
        connectionLimit : 50,
        host: process.env.MYSQL_HOST,
        user: process.env.MYSQL_USERNAME,
        password: process.env.MYSQL_PASSWORD,
        database: process.env.MYSQL_DATABASE
    });
  
    // Attempt to catch disconnects 
    dbconnection.on('connection', function (connection) {
        console.log('DB Connection established');
    
        connection.on('error', function (err) {
        console.error(new Date(), 'MySQL error', err.code);
        });
        connection.on('close', function (err) {
        console.error(new Date(), 'MySQL close', err);
        });
    });

    
    return dbconnection;
}


module.exports = {conn: newConnection()}
