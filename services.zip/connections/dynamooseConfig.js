require('dotenv').config();
const dynamoose = require('dynamoose');

// dynamoose.aws.sdk.config.update({
//     accessKeyId:'AKIAYS2NR6H7YISZXSGT',
//     secretAccessKey: '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',
//     region: 'ap-south-1'
// });



