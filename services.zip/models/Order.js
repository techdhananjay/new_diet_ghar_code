const dynamoose = require("dynamoose");

const { Schema } = dynamoose;


const OrderSchema = new Schema(
    {
        id: { type: String, hashKey: true },
        type: {
            type: String, default: "BUY",
            enum: ["BUY", "SELL"],
            index: { global: true, name: 'OrderTypeIndex' }
        },
        price: { type: Number, default: null },
        quantity: { type: Number, default: null },
        orderStatus: { type: String, default: "PENDING", enum: ["PENDING", "EXECUTED"] },
        shareName: { type: String, default: "ABCVL", index: { global: true, name: 'ShareNameIndex' } },
        userId: { type: String, default: null },
        orderId: { type: String, default: null },
        serialNo: { type: Number, default: null },

        orderkey: { type: String, default: "ALL", index: { global: true, name: 'OrderkeyIndex' } },

        createdAt: {
            type: Date, default: () => new Date(),
            index: {
                global: true, // This makes it a GSI
                name: 'CreatedAtIndex', // Naming the index
                // You can specify other GSI options here
            }
        }
    },
);








module.exports = dynamoose.model("order", OrderSchema);










