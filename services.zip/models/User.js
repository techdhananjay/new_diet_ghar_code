const dynamoose = require("dynamoose");

const { Schema } = dynamoose;


const UserSchema = new Schema(
    {
        id: { type: String, hashKey: true },
        full_name: { type: String, default: null},
        phone: { type: Number, default: null, index: { global: true, name: 'PhoneIndex' } },
        email: { type: String, default: null, index: { global: true, name: 'EmailIndex' } },
        countryCodephoneNo: { type: String, default: null},
        password:{ type: String, default: null},
        birthDate: { type: Date, default: null },

        isPinCreated: { type: Boolean, default: false },
        secretePin: { type: String, default: null},

        ipAddress: { type: String, default: null},


        otp: { type: Number, default: null },
        isOTPVerify: { type: Boolean, default: false },
        otpExpiry: { type: Number, default:null },

        lastlogin: { type: Date },
        loginCount: { type: Number, default:null },
        serialNo: { type: Number, default:null },

        image: { type: String, default: null},
        deviceAddress: { type: String, default: null},
        deviceType: { type: String, default: "PHONE", enum: ["PHONE", "WEB"] },

        isBlocked: { type: Boolean, default: false },
        isDeleted: { type: Boolean, default: false },


        accessToken: { type: String, default: null},
        // permissions: { type: [String], default: [] },
        userKey: { type: String, default: "ALL", index: { global: true, name: 'UserKeyIndex' } },


       


        // encrypted_aadhar_back_image_url: { type: String, default: "" },
        // encrypted_aadhar_front_image_url: { type: String, default: "" },
        // aadhar: { type: String, default: "" },
        // encrypted_pancard_all_data: { type: String, default: "" },
        // encrypted_pancard_image_url: { type: String, default: "" },
        // encrypted_livephoto: { type: String, default: "" },
        // encrypted_livephotodata: { type: String, default: "" },




        createdAt: {
            type: Date, default: () => new Date(),
            index: {
                global: true, // This makes it a GSI
                name: 'CreatedAtIndex', // Naming the index
                // You can specify other GSI options here
            }
        }
    },
    // {
    //     timestamps: true
    // }
);



// // Set virtual attributes
// UserSchema.virtual("fullName").get(function () {
//     return `${this.firstName} ${this.lastName}`;
// });


// // Hashes the password before saving
// UserSchema.pre("save", async function (next) {
//     if (!this.isModified("password")) {
//         return next();
//     }
//     try {
//         const salt = await bcrypt.genSalt(10);
//         const hash = await bcrypt.hash(this.password, salt);
//         this.password = hash;
//         next();
//     } catch (error) {
//         next(error);
//     }
// });


// // Authenticates user by comparing passwords
// UserSchema.authenticate = async function (password) {
//     try {
//         return await bcrypt.compare(password, this.password);
//     } catch (error) {
//         throw new Error("Authentication failed");
//     }
// };


// UserSchema.pre('save', async function (next) {
//     if (!this.id) {
//         try {
//             const counter = await Counter.update({ tableName: 'User' }, { $ADD: { count: 1 } });
//             this.id = counter.count;
//             next();
//         } catch (error) {
//             next(error);
//         }
//     } else {
//         next();
//     }
// });



module.exports = dynamoose.model("user", UserSchema);










