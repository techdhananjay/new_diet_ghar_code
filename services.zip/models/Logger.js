const dynamoose = require("dynamoose");

const { Schema } = dynamoose;

const LoggerSchema = new Schema({
  id: { type: String, hashKey: true },

  url: { type: String, default: null },
  endPoint: {
    type: String,
    default: null,
    index: { global: true, name: "EndPointIndex" },
  },

  method: { type: String, default: null },

  token: { type: String, default: null },
  decodedToken: { type: String, default: null },
  subjectId: { type: String, default: null },

  status: { type: Number, default: null },
  requestTiming: { type: String, default: null },
  requestTimeDuration: { type: Date, default: null },

  // query: { type: Object, default: {} }, // Initialize as an empty object
  // params: { type: Object, default: {} }, // Initialize as an empty object
  body: { type: Object, default: {} }, // Initialize as an empty object
  // files: { type: Object, default: {} }, // Initialize as an empty object
  // finalresponse: { type: Object, default: {} }, // Initialize as an empty object

  query: { type: String, default: null }, // Initialize as an empty String
  params: { type: String, default: null }, // Initialize as an empty String
  // body: { type: String, default: null }, // Initialize as an empty String
  files: { type: String, default: null }, // Initialize as an empty String
  finalresponse: { type: String, default: null }, // Initialize as an empty String

  deviceAddress: { type: String, default: null },
  deviceType: { type: String, default: null, enum: ["PHONE", "WEB"] },

  isBlocked: { type: Boolean, default: false },

  loggerKey: {
    type: String,
    default: null,
    index: { global: true, name: "LoggerKeyIndex" },
  },

  createdAt: {
    type: Date,
    default: () => new Date(),
    index: {
      global: true, // This makes it a GSI
      name: "CreatedAtIndex", // Naming the index
      // You can specify other GSI options here
    },
  },
});

module.exports = dynamoose.model("logger", LoggerSchema);
