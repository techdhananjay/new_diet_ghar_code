const dynamoose = require("dynamoose");

const { Schema } = dynamoose;


const CounterSchema = new Schema(
    {
        id: { type: String, hashKey: true },
        user: { type: Number, default: 0 },
        admin: { type: Number, default: 0 },
        order: { type: Number, default: 0 },
        transaction: { type: Number, default: 0 },
        executedOrder: { type: Number, default: 0 },
        counterKey: { type: String, default: "ALL", index: { global: true, name: 'CounterKeyIndex' } },

    },
    {
        timestamps: true
    }
);





module.exports = dynamoose.model("counter", CounterSchema);






