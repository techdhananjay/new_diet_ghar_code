const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const bcrypt = require("bcryptjs");
const constants = require("../../common/constants");
const ObjectId = mongoose.Types.ObjectId;

const DocSchema = new Schema(
  {
    firstName: { type: String,default: "",},
    lastName: {type: String, default: "", },
    email: { type: String, default: "", index: true, },
    username:{ type: String,default: "",},
    password: { type: String, default: "", },
    image: {type: String, default: "", },
    avatar: {type: Object, default: {} },
    phoneNo: { type: String, default: "", },
    isEmailVerified: {type: Boolean, default: false, },
    email_verified: {type: Boolean, default: false, },
    isPhoneVerified: { type: Boolean,default: false,},
    countryCodephoneNo: {type:String , default: " ", },
    birthDate: { type: Date, default: new Date(), },
    address: { type: String, default: "", },
    city: { type: String, default: "", },
    nationality: { type: String,default: "", index: true,},
    
    isActive: { type: Boolean, default: true, },
    isBlocked: {type: Boolean, default: false,},
    isDeleted: {type: Boolean, default: false,},
    accessToken: { type: String, default: "", index: true, },
    
    role: { type: String, default: "customer", enum: ["customer", "store_owner","super_admin"],},
    permissions:{type:[],default:[]},
    secretCode: {  type: String, default: "",},
    secretExpiry: { type: Date, default: 0,},
    tempData: { type: Object, default: {}, },
   
    lastlogin: { type: Date, },
    loginCount: {type: Number, default: 0, },

  },

  {
    timestamps: true,
  }
);




DocSchema.index({
  dialCode: 1,
  phoneNo: 1,
});

DocSchema.set("toJSON", {
  getters: true,
  virtuals: true,
});


DocSchema.methods.setPassword = function (password, callback) {
  const promise = new Promise((resolve, reject) => {
    if (!password) reject(new Error("Missing Password"));

    bcrypt.hash(password, 10, (err, hash) => {
      if (err) reject(err);
      this.password = hash;
      resolve(this);
    });
  });

  if (typeof callback !== "function") return promise;
  promise
    .then((result) => callback(null, result))
    .catch((err) => callback(err));
};

DocSchema.methods.authenticate = function (password, callback) {
  const promise = new Promise((resolve, reject) => {
    if (!password) reject(new Error("MISSING_PASSWORD"));

    bcrypt.compare(password, this.password, (error, result) => {
      if (!result) reject(new Error("INVALID_PASSWORD"));
      resolve(this);
    });
  });

  if (typeof callback !== "function") return promise;
  promise
    .then((result) => callback(null, result))
    .catch((err) => callback(err));
};

DocSchema.virtual("fullName")
  .get(function () {
    return this.firstName + " " + this.lastName;
  })
  .set(function (val) {
    this.firstName = val.substr(0, val.indexOf(" "));
    this.lastName = val.substr(val.indexOf(" ") + 1);
  });

DocSchema.index({
  location: "2dsphere",
});
module.exports = mongoose.model("User", DocSchema);




