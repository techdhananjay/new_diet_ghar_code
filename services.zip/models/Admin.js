const dynamoose = require("dynamoose");

const { Schema } = dynamoose;

const bcrypt = require("bcryptjs");



const AdminSchema = new Schema(
    {
        id: { type: String, hashKey: true },
        full_name: { type: String, default:null },
        adminId: { type: String, default: null },
        userName: { type: String, default: null, index: { global: true, name: 'UserNameIndex' } },
        phone: { type: Number, default: null, index: { global: true, name: 'PhoneIndex' } },
        email: { type: String, default: null, index: { global: true, name: 'EmailIndex' } },
        password: { type: String, default: null },
        password_2: { type: String, default:null },
        countryCodephoneNo: { type: String, default: null },
        birthDate: { type: Date, default: null },
        ipAddress: { type: String, default: null },
        // otp: { type: Number, default: 0 },
        // otpExpiry: { type: Number, default: 0 },
        // isOTPVerify: { type: Boolean, default: false },
        // lastlogin: { type: Date },
        // loginCount: { type: Number, default: 0 },
        serialNo: { type: Number, default: 0 },


        isBlocked: { type: Boolean, default: false },
        isDeleted: { type: Boolean, default: false },
        accessToken: { type: String, default:null, },
        role: { type: String, default: "ADMIN", enum: ["ADMIN", "SUPER_ADMIN"] },
        adminKey: { type: String, default: "ALL", index: { global: true, name: 'AdminKeyIndex' } },

        // permissions: { type: [String],  default: [] },
    },
    {
        timestamps: true
    }
);



module.exports = dynamoose.model("admin", AdminSchema);


