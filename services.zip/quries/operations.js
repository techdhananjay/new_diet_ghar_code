const { v4: uuidv4 } = require("uuid");


module.exports.getItemById = async (Model, id) => {
	try {
		// Use the Model's get method to retrieve the item by its ID
		return await Model.get(id);
	} catch (error) {
		console.error("Error getting item by ID:", error);
		throw error;
	}
};


module.exports.getItemByIdExpecificElement = async (Model, id, attributes = ['isaadharkyc', 'ispankyc', 'islivephoto']) => {
    try {
        // Use the Model's get method to retrieve the item by its ID with specific fields
        const options = {
            attributes: attributes // Specify the fields to retrieve
        };
        return await Model.get(id, options);
    } catch (error) {
        console.error("Error getting item by ID:", error);
        throw error;
    }
};

module.exports.insertItem = async (Model, itemData) => {
	try {

		if (!itemData.id) itemData.id = uuidv4()
		// Create a new item using the Model's create method
		const newItem = await Model.create(itemData);

		// Return the newly inserted item
		return newItem;


	} catch (error) {
		console.error("Error inserting item:", error);
		throw error;
	}
};

module.exports.updateItemById = async (Model, id, updateData) => {
	try {
		// Use the Model's update method to update the item by its ID
		const updatedItem = await Model.update({ id }, updateData);

		// Return the updated item
		return updatedItem;
	} catch (error) {
		console.error("Error updating item by ID:", error);
		throw error;
	}
};

module.exports.deleteItemById = async (Model, id) => {
	try {
		// Use the Model's delete method to delete the item by its ID
		const deletedItem = await Model.delete(id);

		// Return the deleted item
		return deletedItem;
	} catch (error) {
		console.error("Error deleting item by ID:", error);
		throw error;
	}
};

module.exports.getAllItemsWithFilter = async (
	Model,
	filterObj = {},
	limit = 30
) => {
	try {
		// Perform a scan operation to retrieve all items from the table
		return await Model.scan(filterObj).limit(limit).exec();
	} catch (error) {
		console.error("Error retrieving items:", error);
		throw error;
	}
};

module.exports.getAllItemsByQueryKey = async (
	Model,
	dataObj,
	limit = 30,
	record = "ONE"
) => {
	// Extracting the key and value dynamically from the data object
	const [queryKey, queryValue] = Object.entries(dataObj)[0];

	if (queryKey && queryValue) {
		try {
			const items = await Model.query(queryKey)
				.eq(queryValue)
				.limit(record == "ONE" ? 1 : limit)
				.exec();
			if (items && items.count > 0) {
				if (record == "ONE") return items[0];
				if (record == "ALL") return items;
			} else {
				return null;
			}
		} catch (error) {
			console.error("Error querying items:", error);
			throw error;
		}
	} else {
		throw new Error("Invalid data object provided");
	}
};

module.exports.getAllItemsByQueryWithFilter = async (
	Model,
	dataObj,
	filterObj = {},
	limit = 30,
	record = "ONE"
) => {
	// Extracting the key and value dynamically from the data object
	const [queryKey, queryValue] = Object.entries(dataObj)[0];

	if (queryKey && queryValue) {
		try {
			// Apply additional filtering conditions from filterObj
			const query = Model.query(queryKey).eq(queryValue).filter(filterObj);

			// Apply limit based on the record parameter
			if (record === "ONE") {
				query.limit(1);
			} else {
				query.limit(limit);
			}

			// Execute the query
			const items = await query.exec();

			if (items && items.count > 0) {
				if (record === "ONE") return items[0];
				if (record === "ALL") return items;
			} else {
				return null;
			}
		} catch (error) {
			console.error("Error querying items:", error);
			throw error;
		}
	} else {
		throw new Error("Invalid data object provided");
	}
};




module.exports.getAllDataWithPagination_Old = async (
	Model,
	filterObj = {},
	searchInput = {},
	limit = 10,
	page = 1,
	exclusiveStartKey = null // Add a parameter to accept the start key
) => {
	try {

		let exclusiveKey = exclusiveStartKey ? { id: exclusiveStartKey } : null

		const result = await Model.scan(filterObj)
			.startAt(exclusiveKey) // This assumes startAt is the correct method for setting the exclusive start key in your version of Dynamoose.
			.limit(limit)
			.exec();
		const totalItem = await Model.scan(filterObj).count().exec()
		const items = result; // This will contain your scanned items.
		let lastEvaluatedKey = result?.lastKey?.id ?? null; // Dynamoose uses result.lastKey to store the LastEvaluatedKey.
		return {
			items,
			page,
			lastEvaluatedKey, // Return this to the client for the next page request
			limit,
			totalItem
		};
	} catch (error) {
		console.error("Error retrieving data with pagination:", error);
		throw error;
	}
};


module.exports.getAllDataWithPagination = async (
	Model,
	filterObj = {},
	searchInput = {},
	limit = 10,
	page = 1,
	exclusiveStartKey = null
) => {
	try {
		let scanOperation = Model.scan(filterObj);

		// Applying search filters based on searchInput
		for (const [key, value] of Object.entries(searchInput)) {
			if (value) {
				scanOperation = scanOperation.and().where(key).contains(value);
			}
		}

		// Setting the exclusive start key if provided
		let exclusiveKey = exclusiveStartKey ? { id: exclusiveStartKey } : null;
		if (exclusiveKey) {
			scanOperation = scanOperation.startAt(exclusiveKey);
		}

		// Execute the scan operation with limit
		const results = await scanOperation.limit(limit).exec();

		// Count total items (note: this can be very expensive on large tables)
		const totalItem = await Model.scan(filterObj).count().exec();

		const items = results; // This will contain your scanned items.
		let lastEvaluatedKey = results.lastKey ? results.lastKey.id : null; // Dynamoose uses results.lastKey to store the LastEvaluatedKey.

		return {
			items,
			page,
			lastEvaluatedKey, // Return this to the client for the next page request
			limit,
			totalItem: totalItem.count // Ensure you extract the count correctly
		};
	} catch (error) {
		console.error("Error retrieving data with pagination and search:", error);
		throw error;
	}
};

// const regex = new RegExp(searchQuery, "i"); // Case-insensitive regex search

module.exports.findUsersByMultipleFieldsContains_old = async (Model, searchQuery) => {
	try {
		const results = await Model.scan({ isDeleted: true })
			.filter('full_name').contains(searchQuery)
			.or()
			.filter('email').contains(searchQuery)
			.or()
			.filter('address').contains(searchQuery)
			.exec();
		return results;
	} catch (error) {
		console.error("Error searching for users:", error);
		throw error;
	}
}


module.exports.findUsersByMultipleFieldsAndConditions_old = async (Model, searchQuery) => {
	try {
		const results = await Model.scan()
			// .filter('status').eq('Approved') // Filter for status = "Approved"
			// .and()
			// .filter('isDeleted').eq(false) // Filter for isDeleted = false
			// .and()
			.where('status').eq('Approved') // Filter for status = "Approved"
			.and()
			.where('isDeleted').eq(false) // Filter for isDeleted = false
			.and()
			.parenthesis() // Start of the parenthesis for OR conditions
			.filter('full_name').contains(searchQuery)
			.or()
			.filter('email').contains(searchQuery)
			.or()
			.filter('address').contains(searchQuery)
			.closeParenthesis() // End of the parenthesis for OR conditions
			.exec();

		return results;
	} catch (error) {
		console.error("Error searching for users:", error);
		throw error;
	}
}


module.exports.findUsersByMultipleFieldsAndConditions_old = async (Model, searchQuery) => {
	try {
		const results = await Model.scan('isDeleted').eq(true) // Filter for isDeleted: true
			.filter('full_name').contains(searchQuery)
			.or()
			.filter('email').contains(searchQuery)
			.or()
			.filter('address').contains(searchQuery)
			.exec();
		return results;
	} catch (error) {
		console.error("Error searching for users:", error);
		throw error;
	}
}


module.exports.findUsersByMultipleFieldsAndConditions = async (Model, searchQuery, filterObj) => {
	let scan = Model.scan();
	let searchInputFields = ["full_name", "email", "address"]
	// Applying filters from the filter object
	Object.keys(filterObj).forEach((key) => {
		scan = scan.filter(key).eq(filterObj[key]);
	});

	if (searchQuery) {
		// Building a condition for the search query across multiple fields
		let searchConditions = searchInputFields.map((field) => {
			return { [field]: { contains: searchQuery } };
		});

		// Applying OR condition across multiple fields for the search query
		scan = scan.and().or(...searchConditions);
	}

	try {
		const results = await scan.exec();
		return results;
	} catch (error) {
		console.error('Error executing scan:', error);
		throw error;
	}
}
