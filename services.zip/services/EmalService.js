
var nodemailer = require('nodemailer');
var transporter_1 = nodemailer.createTransport({
    service: 'gmail',
    secure: false,
    auth: {
        user: process.env.SERVICE_EMAIL_USER_NAME,
        pass: process.env.SERVICE_EMAIL_PASS
    },
    tls: {
        rejectUnauthorized: false
    }
});


const transporter = nodemailer.createTransport({
    host: 'email-smtp.ap-south-1.amazonaws.com',
    port: 587,
    secure: false,
    auth: {
        user: 'AKIAYS2NR6H7SW7W7IU7',
        pass: 'BC030lsyn296m03XPEec8fjKHctAwLLOkxfBpO41TO3S'
    }
});



exports.send = async function (payload) {

    const msg = {
        to: payload.to,
        from: process.env.SERVICE_EMAIL,
        subject: payload.title,
        html: payload.message
    }
    try {
        // const info = await transporter.sendMail(msg);
        // console.log(`Message sent: ${ info.response }`);
        return await transporter.sendMail(msg);
    }
    catch (err) {
        return err;
    }
}



async function sendEmail(toEmail) {
    const mailOptions = {
        from: 'no-reply@simplyfy.trade',
        to: toEmail,
        subject: 'Test Email from Amazon SES',
        text: 'Hello, this is a test email sent from Amazon SES via SMTP.',
        html: '<p>Hello, this is a test email sent from Amazon SES via SMTP.</p>'
    };

    try {

        const info = await transporter.sendMail(mailOptions);
        console.log(`Message sent: ${ info.response }`);
    } catch (error) {
        console.log(`Error: ${ error }`);
    }
}


