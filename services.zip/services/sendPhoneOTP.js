
const axios = require('axios');
module.exports.sendotp = async (phone_number, otp) => {

    var config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: `https://2factor.in/API/V1/08213949-d0b1-11ee-8cbb-0200cd936042/SMS/${phone_number}/${otp}/OTPNew?var=2`,
        headers: {}
    };

    try {
        const response = await axios(config)
        if (response.data) {
            return true
        } else {
            throw new Error("msg not  send")
        }
    } catch (error) {
        console.log("error :-", error)
        return false
    }

    // axios(config)
    //     .then(function (response) {
    //         console.log(JSON.stringify(response.data));
    //     })
    //     .catch(function (error) {
    //         console.log(error);
    //     });
}
