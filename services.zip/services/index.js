module.exports = {
  EmailService: require("./EmalService"),
  SendPhoneOtp:require('./sendPhoneOTP')
  // Redish:require('./redis'),
  //  smsService: require("./smsService")
};
