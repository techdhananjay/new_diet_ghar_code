const redis = require('redis');
const util = require("util");

// const client = redis.createClient({ host: 'localhost', port: 6379 });

const redishUrl = process.env.REDISH_URL || "redis://127.0.0.1:6379";
const client = redis.createClient(redishUrl);


client.set = util.promisify(client.set);
client.get = util.promisify(client.get);
client.del = util.promisify(client.del);


async function getCachedData(cacheKey) {
    return await client.get(cacheKey)
}


async function setCachedData(cacheKey, data, expiresIn = 3600) {
    return await client.setex(cacheKey, expiresIn, JSON.stringify(data));
}

async function deleteCachedData(cacheKey) {
    return await client.del(cacheKey)
}



module.exports = {
    RedisServer: redis,
    RedishClient: client,
    getCachedData,
    setCachedData,
    deleteCachedData
}


