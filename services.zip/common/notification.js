const admin = require("firebase-admin");
admin.initializeApp({
    //databaseURL: 'https://<DATABASE_NAME>.firebaseio.com',
    credential: admin.credential.cert({
        projectId: process.env.projectId,
        clientEmail: process.env.clientEmail,
        privateKey: process.env.privateKey
    })
});
// admin.initializeApp({ credentials: admin.credential.cert(serviceAccount) });
module.exports.sendSingleNotification = async (token, title, body, data,userId) => {

    console.log(token);
    console.log(title);
    console.log('');
    //   var message = {
    //     //this may vary according to the message type (single recipient, multicast, topic, et cetera)
    //     to: token,
    //     notification: {
    //       title: title,
    //       body: body,
    //       "click_action":"FLUTTER_NOTIFICATION_CLICK",
    //     },
    //     data: data,
    //     "priority": "high",

    //   };
    try {
        const notificationRes = await admin.messaging().sendToDevice(
            token,
            {
                notification: {
                    title,
                    body: body,
                    tag: "newMessage",
                    color: "#18d821",
                    sound: "default",
                    clickAction: "FLUTTER_NOTIFICATION_CLICK",
                },
            },
            {
                timeToLive: 86400,
                priority: "high",
            }
        );
        console.log("notificationRes",notificationRes);
        console.log("notificationRes.results[0]",notificationRes.results[0]);
        console.log("notificationRes.results[0].messageId",notificationRes.results[0].messageId);
        if (notificationRes.results[0].messageId) {
            // const date = new Date();
            // const newNotification = await Notification.create({
            //  title,
            //  message: body,
            //  category: 'SINGLE',
            //  date,
            //  data: {
            //     userId
            //  }
            // });
            //return res.success("Notification sended!", {message:"message send"});
            return true;
           } else {
            console.log('notification not send ');
            return false;
           }
    } catch (error) {
        console.log(error);
        return false;
    //    return res.error(401, error.message);;
    }
   
};



module.exports.sendMultiPleNotification = async (token, title, body, data,userId) => {
     
      const notificationRes = await admin.messaging().sendToDevice(
        token,
        {
            notification: {
                title,
                body: body,
                tag: "newMessage",
                color: "#18d821",
                sound: "default",
                clickAction: "FLUTTER_NOTIFICATION_CLICK",
            },
        },
        {
            timeToLive: 86400,
            priority: "high",
        }
      );
      if (notificationRes) {
        console.log(notificationRes.results)
        return notificationRes.results;
    }else{
        console.log(notificationRes)
        return "some error occurred"
    }
}               