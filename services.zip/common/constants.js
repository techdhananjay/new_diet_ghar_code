module.exports = {
    segments : {
        ALLCUSTOMERS : 1,
        ACTIVECUSTOMERS : 2,
        LAPSEDCUSTOMERS : 3,
        TOPCUSTOMERSTIME: 4,
        CUSTOMERSBYAGEANDCOUNTRY: 5
    },
    ACTIVECUSTOMERTYPE : {
        LAST30DAYS : 0,
        LAST60DAYS : 1,
        LAST90DAYS : 2,
        CUSTOM : 3
    },
    LAPSEDCUSTOMERS : {
        LAST30DAYS : 0,
        LAST60DAYS : 1,
        LAST90DAYS : 2,
        CUSTOM : 3
    },
    TOPCUSTOMERSTIME : {
        LAST30DAYS : 0,
        LAST60DAYS : 1,
        LAST90DAYS : 2,
        CUSTOM : 3
    },
    SELECTCOUNTRY: {
        ALL : 1,
        CUSTOM : 2
    },
    BRANDOUTLETSTYPE : {
        FOODANDBEVERAGE : 1,
        BEAUTYANDFITNESS : 2,
        FASHIONANDRETAIL : 3,
        SERVICES : 4,
        FLOWERSANDGIFTS : 5
    },
    SUBSCRIPTIONPLANTYPE:{
        LAST30DAYS : 0,
        LAST90DAYS : 1,
        LAST183DAYS : 2,
        LAST365DAYS : 3,
        CUSTOM:4
    },
    
    
};





