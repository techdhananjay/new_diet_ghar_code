const { S3Client } = require("@aws-sdk/client-s3");
const multer = require("multer");
const multerS3 = require("multer-s3");



const s3Client = new S3Client({
    endpoint: "https://simplyfydev.blr1.digitaloceanspaces.com",
    credentials: {
      accessKeyId: process.env.DO_SPACES_KEY,
      secretAccessKey: process.env.DO_SPACES_SECRET,
    },
    region: "blr1",
    forcePathStyle: true,
  });
  
  const configureUpload = (fileFields, options = {}) => {

    console.log("upload files")
    return multer({
      storage: multerS3({
        s3: s3Client,
        bucket: process.env.DO_SPACES_BUCKET,
        acl: options.acl || "public-read",
        key: function (request, file, cb) {
          let folderName;
          console.log('console.log(file.fieldname);',file.fieldname);
          switch (file.fieldname) {
            
            case "aadhar_back":
            case "aadhar_front":

              folderName = "aadhar";
              break;
            case "pancard":
              folderName = "pan-card";
              break;
              case "photo":
                folderName = "live-photo";
                break;
            default:
              folderName = "others";
          }
  
          const fileName = options.fileNameGenerator
            ? options.fileNameGenerator(request, file)
            : `${folderName}/${file.originalname}`; 
          cb(null, fileName);
        },
        ...options.s3Options,
      }),
    }).fields(fileFields);
  };

  module.exports={
    configureUpload
  }