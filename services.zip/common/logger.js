const jwt = require("jsonwebtoken");
const Query = require("../quries/operations");
// const Model = require("../models");
const Auth = require("./authenticate");
const MYSQL = require("../connections/mysql").conn;

module.exports = () => (req, res, next) => {
  const { method, url } = req;
  const query = req.query;
  const body = req.body;
  const params = req.params;
  const start = Date.now(); // Start timing here

  const date = new Date(start);
  const isoDate = date.toISOString();

  const token = String(req.headers.authorization || "")
    .replace(/bearer|jwt/i, "")
    .replace(/^\s+|\s+$/g, "");

  let decodedToken = token ? Auth.verifyToken(token) : {};

  const files = req.files;

  // Capture the original send/response methods to wrap them later
  const originalSend = res.send.bind(res);
  const originalJson = res.json.bind(res);
  const originalStatus = res.status.bind(res);

  let loggedResponse;
  let responseStatus = 200; // Default status

  // Wrap the status method to capture status codes
  res.status = (statusCode) => {
    responseStatus = statusCode;
    return res;
  };

  // A function to log the collected data
  const logDetails = (responseData) => {
    const data = responseData ? JSON.parse(responseData) : null;
    let resDoc = {
      statusCode: data?.statusCode,
      message: data?.message,
    };
    const segments = url.split("/"); // Split the URL by '/'

    const duration = Date.now() - start; // Calculate duration

    const itemData = {
      url: url,
      endPoint: segments[3],
      method: method,
      token: token,
      decodedToken: JSON.stringify(decodedToken),
      subjectId: decodedToken.id ?? null,
      status: responseStatus,
      requestTiming: isoDate,
      requestTimeDuration: duration,
      query: JSON.stringify(query),
      body: JSON.stringify(body),
      params: JSON.stringify(params),
      files: files
        ? JSON.stringify(files.map((file) => file.originalname).join(", "))
        : "{}",
      finalresponse: JSON.stringify(resDoc),
      // Add other properties as needed
    };

    // console.log("logger item data ", itemData)

    // Query.insertItem(Model.Logger, itemData)
    //   .then(newItem => {
    //     console.log("Logger inserted successfully:", newItem);
    //     // Handle success
    //   })
    //   .catch(error => {
    //     console.error("Error inserting logger:", error);
    //     // Handle error
    //   });




    console.log("logger item data ", itemData);
    var query = "INSERT INTO `logged` (url, method, token) VALUES ('" + url + "','" + method + "','" + token + "')";
    commitQuery(query)
    // Query.insertItem(Model.Logger, itemData)
    //   .then((newItem) => {
    //     console.log("Logger inserted successfully:", newItem);
    //     // Handle success
    //   })
    //   .catch((error) => {
    //     console.error("Error inserting logger:", error);
    //     // Handle error
    //   });


    // console.log(`Logger Details
    //   - Method: ${method}
    //   - URL: ${url}
    //   - Segment: ${segments[3]}
    //   - Token : ${token}
    //   - Decoded Token : ${JSON.stringify(decodedToken)}
    //   - Status: ${responseStatus}
    //   - Api Request Time :${isoDate}
    //   - EndPoint Time: ${duration}ms
    //   - Query: ${JSON.stringify(query)}
    //   - Body: ${JSON.stringify(body)}
    //   - Params: ${JSON.stringify(params)}
    //   - Files: ${files ? files.map(file => file.originalname).join(', ') : 'No files'}
    //   - Response: ${JSON.stringify(resDoc)}`);
  };

  // Optionally, wrap the json method if you're using it to send JSON responses
  res.json = (data) => {
    loggedResponse = JSON.stringify(data); // Ensure logging of JSON as string
    logDetails(loggedResponse); // Log the details when response is sent
    res.json = originalJson; // Restore original json to avoid issues in Express
    return originalJson(data);
  };

  Query.insertItem;

  next();
};



function commitQuery(query, res) {
  if (!MYSQL) {
    console.log("Could not connect to database!");
    return res.send({ "message": "Could not connect to the database" });
  } else {
    MYSQL.query(query, function (err, result) {
      if (err) {
        return res.send({ "message": "Error executing query" + err });
      } else {
        console.log("Query Success!" ,result);
       
      }
    });
  }
}


// Wrap the send method to log response data
// res.send = (data) => {
//     loggedResponse = data;
//     logDetails(loggedResponse); // Log the details when response is sent
//     res.send = originalSend; // Restore original send to avoid issues in Express
//     return originalSend(data);
// };
