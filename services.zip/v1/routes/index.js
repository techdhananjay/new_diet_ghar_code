const router = require("express").Router();
const UserRoutes = require("./User");
const AdminRoutes = require("./Admin");
const FileUploadRoutes = require("./files");
const CounterRoutes = require("./counter");

router.use("/User", UserRoutes);
router.use("/Admin", AdminRoutes);
router.use("/file", FileUploadRoutes);

router.use("/counter", CounterRoutes);





module.exports = router;

