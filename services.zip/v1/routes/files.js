const router = require("express").Router();
require("dotenv").config();
const { configureUpload } = require("../../common/uploadfile");

const Auth = require("../../common/authenticate");
const Controller = require("../controllers");

const uploadFields = [
  { name: "aadhar_back", maxCount: 1 },
  { name: "aadhar_front", maxCount: 1 },
  { name: "pancard", maxCount: 1 },
  { name: "photo", maxCount: 1 },
];

router.post(
  "/aadharcardverification",
  configureUpload(uploadFields),
  Controller.UserFile.aadhar_card_verification
);

router.post(
  "/pancardverification",
  configureUpload(uploadFields),
  Controller.UserFile.pancard_verification
);

router.post(
  "/livephoto",
  configureUpload(uploadFields),
  Controller.UserFile.livephoto
);


module.exports = router;
