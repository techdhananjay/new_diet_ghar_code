const router = require("express").Router();


const Controller = require("../controllers");

// ONBOARDING API'S  



router.post("/", Controller.Counter.create);
router.get("/", Controller.Counter.get);



module.exports = router;


  

