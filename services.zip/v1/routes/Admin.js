const router = require("express").Router();
const multer = require("multer");


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/uploads");
  },
  filename: function (req, file, cb) {
    const name = Date.now() + "-" + file.originalname;
    cb(null, name);
  },
});

const upload = multer({ storage });


const Auth = require("../../common/authenticate");
const Controller = require("../controllers");


router.post("/register", Controller.Admin.register);
router.post("/login", Controller.Admin.login);
router.post("/changePassword", Controller.Admin.changePassword);

router.get("/profile", Auth.verify('admin'), Controller.Admin.getProfile);
router.get("/profile/:id", Auth.verify('admin'), Controller.Admin.getProfile);
router.post("/logout", Auth.verify('admin'), Controller.Admin.logout);


router.get("/user", Controller.Admin.getAllUser); //for add admin
router.get("/user/:id", Controller.Admin.getUserProfile); //for add admin


// router.post("/attachments", upload.array('attachment[]', 5), Controller.User.attachments);

 
router.get("/aadhar_card_get", Controller.Admin.get_aadhar_card);




module.exports = router;





