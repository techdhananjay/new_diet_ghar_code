const router = require("express").Router();
const multer = require("multer");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/uploads");
  },
  filename: function (req, file, cb) {
    const name = Date.now() + "-" + file.originalname;

    cb(null, name);
  },
});



const upload = multer({ storage });
const Auth = require("../../common/authenticate");
const Controller = require("../controllers");

// ONBOARDING API'S  






// router.post("/register", Controller.User.register);



router.post("/login", Controller.User.login,);
router.post("/otpVerify", Controller.User.verifyOtp);

router.post("/sendOtp", Controller.User.sendOtp);

router.get("/", Auth.verify("user"), Controller.User.getProfile); // Get user profile by access Token
router.post("/logout", Auth.verify("user"), Controller.User.logout);
router.post("/getAllUser", Auth.verify("user"), Controller.User.getAllUser);






module.exports = router;










































































