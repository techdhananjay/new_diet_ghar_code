var axios = require("axios");
var FormData = require("form-data");
var fs = require("fs");
const path = require("path");
const CryptoJS = require("crypto-js");
const Query = require("../../quries/operations");
const Model = require("../../models");

module.exports.aadhar_card_verification = async (req, res, next) => {
  const aadharFront = req.files.aadhar_front
    ? req.files.aadhar_front[0].location
    : null;
  const aadharBack = req.files.aadhar_back
    ? req.files.aadhar_back[0].location
    : null;
  const { id } = req.body;

  try {
    const Items = await Query.getAllItemsByQueryKey(Model.User, { id: id });

    // if (Items.aadhar) {
    //   return res.success("Aadhar Kyc Already Done");
    // }
    const encrypted_aadhar_back = CryptoJS.AES.encrypt(
      aadharBack,
      process.env.SECRET_PARSE_KEY
    ).toString();

    const encrypted_aadhar_front = CryptoJS.AES.encrypt(
      aadharFront,
      process.env.SECRET_PARSE_KEY
    ).toString();

    if (aadharBack && aadharFront) {
      const backResponse = await apiforaadharkyc(aadharBack);
      const frontResponse = await apiforaadharkyc(aadharFront);
      const aadhar_back_data = backResponse.data.ocr_fields[0];
      const aadharcardfrontdata = frontResponse.data.ocr_fields[0];
    if(Items.full_name === aadharcardfrontdata.full_name.value && Items.DateOfBirth  === aadharcardfrontdata.dob.value ){

      
      const aadharData = {
        aadhar_front_data: {
          full_name: aadharcardfrontdata.full_name.value,
          gender: aadharcardfrontdata.gender.value,
          dob: aadharcardfrontdata.dob.value,
          aadhaar_number: aadharcardfrontdata.aadhaar_number.value,
        },
        aadhar_back_data: {
          father_name: aadhar_back_data.care_of.value,
          pincode: aadhar_back_data.address.zip,
          state: aadhar_back_data.address.state,
          house_number: aadhar_back_data.address.house_number,
          city: aadhar_back_data.address.city,
          landmark: aadhar_back_data.address.landmark,
          locality: aadhar_back_data.address.locality,
          value: aadhar_back_data.address.value,
        },
      };

      const encryptedAadharData = CryptoJS.AES.encrypt(
        JSON.stringify(aadharData),
        process.env.SECRET_PARSE_KEY
      ).toString();

      Items.aadhar = encryptedAadharData;
      Items.encrypted_aadhar_back_image_url = encrypted_aadhar_back;
      Items.encrypted_aadhar_front_image_url = encrypted_aadhar_front;
      Items.isaadharkyc = true
      Items.isApproved = "APPROVED"

      await Items.save();

      const response = {
        aadhaar_front_bottom: {
          status: frontResponse.status_code,
          message_code: frontResponse.message_code,
          document_type: aadharcardfrontdata.document_type,
          data: aadharData.aadhar_front_data
        },
        aadhaar_back: {
          status: backResponse.status_code,
          message_code: backResponse.message_code,
          document_type: aadhar_back_data.document_type,
          data: aadharData.aadhar_back_data

        },
      };
      return res.success("aadhar_card kyc Done", response);
    }else{
      Items.isApproved  = "SEMI_APPROVED"
      await Items.save();
      return res.error("Document mismatched",{});

    }
    }
    return res.error("aadhar front and aadhar back are required", {});
  } catch (error) {
    console.error(error);
    next(error);
  }
};

module.exports.pancard_verification = async (req, res, next) => {
  try {
    const pancard = req.files.pancard ? req.files.pancard[0].location : null;
    const id = req.body.id;

    const Items = await Query.getAllItemsByQueryKey(Model.User, { id: id });

    if (Items.encrypted_pancard_all_data) {
      return res.success("Pan Card  Kyc Already Done");
    }

    if (pancard) {
      const pancardresponse = await Apiforpancardverification(pancard);
      const pancard_data = pancardresponse.data.ocr_fields[0];
      const pancard_all_data = {
        pan_number: pancard_data.pan_number.value,
        full_name: pancard_data.full_name.value,
        father_name: pancard_data.father_name.value,
        dob: pancard_data.dob.value,
      };
      
        
        const encrypted_pancard_all_data = CryptoJS.AES.encrypt(
          JSON.stringify(pancard_all_data),
          process.env.SECRET_PARSE_KEY
        ).toString();
  
        const encrypted_pancard = CryptoJS.AES.encrypt(
          JSON.stringify(pancard),
          process.env.SECRET_PARSE_KEY
        ).toString();

        Items.DateOfBirth = pancard_data.dob.value;
        Items.full_name = pancard_data.full_name.value
        Items.encrypted_pancard_image_url = encrypted_pancard;
        Items.encrypted_pancard_all_data = encrypted_pancard_all_data;
        Items.ispankyc = true
  
        const data = await Items.save();
        console.log("pancard Data save", data);
        const response = {
          status: pancardresponse.status_code,
          message_code: pancardresponse.message_code,
          document_type: pancard_data.document_type,
          pan_Data: pancard_all_data,
        };
        Items.isApproved  = "SEMI_APPROVED"
        return res.success("PanCard kyc Done", response);
      }else{

        return res.error("document mismatched" , {})
      }

    
  } catch (error) {
    next(error);
  }
};


module.exports.livephoto = async (req, res, next) => {
  const livephoto = req.files.photo ? req.files.photo[0].location : null;
  const { id, Data } = req.body;

  try {
    const Items = await Query.getAllItemsByQueryKey(Model.User, { id: id });

    if (Items.livephoto) {
      return res.success("livephoto Already Done");
    }

    const encrypted_livephoto = CryptoJS.AES.encrypt(
      livephoto,
      process.env.SECRET_PARSE_KEY
    ).toString();

    const encrypted_livephotodata = CryptoJS.AES.encrypt(
      Data,
      process.env.SECRET_PARSE_KEY
    ).toString();

    if (Data) {
      Items.encrypted_livephoto = encrypted_livephoto;
      Items.encrypted_livephotodata = encrypted_livephotodata;
      Items.islivephoto = true
      await Items.save();

      return res.success("Live Photo Data Saved", Items);
    }
    return res.success("Live Photo Data are required", {});
  } catch (error) {
    console.error(error);
    next(error);
  }
};

async function downloadFile(fileUrl, outputPath) {
  const directory = path.dirname(outputPath);
  fs.mkdirSync(directory, { recursive: true });

  const writer = fs.createWriteStream(outputPath);

  const response = await axios({
    url: fileUrl,
    method: "GET",
    responseType: "stream",
  });

  response.data.pipe(writer);

  return new Promise((resolve, reject) => {
    writer.on("finish", () => resolve(outputPath));
    writer.on("error", reject);
  });
}

async function Apiforpancardverification(fileUrl) {
  console.log("pancard verification processing ......");
  const downloadFolder = "./downloadedFiles";
  const fileName = fileUrl.split("/").pop();
  const filePath = path.join(downloadFolder, fileName);

  await downloadFile(fileUrl, filePath);

  var data = new FormData();
  data.append("file", fs.createReadStream(filePath));

  var config = {
    method: "post",
    url: "https://sandbox.surepass.io/api/v1/ocr/pan",
    headers: {
      ...data.getHeaders(),
      Authorization: `Bearer ${process.env.API_auth_token}`,
    },
    data: data,
    maxBodyLength: Infinity,
  };

  return axios(config)
    .then(function (response) {
      return response.data;
    })
    .catch(function (error) {
      throw error;
    });
}

async function apiforaadharkyc(fileUrl) {
  console.log("aadhar card verification");
  const downloadFolder = "./downloadedFiles";
  const fileName = fileUrl.split("/").pop();
  const filePath = path.join(downloadFolder, fileName);

  await downloadFile(fileUrl, filePath);

  var data = new FormData();
  data.append("file", fs.createReadStream(filePath));

  var config = {
    method: "post",
    url: "https://sandbox.surepass.io/api/v1/ocr/aadhaar",
    headers: {
      ...data.getHeaders(),
      Authorization: `Bearer ${process.env.API_auth_token}`,
    },
    data: data,
    maxBodyLength: Infinity,
  };

  return axios(config)
    .then(function (response) {
      return response.data;
    })
    .catch(function (error) {
      throw error;
    });
}





