
const { v4: uuidv4 } = require("uuid");
const Query = require("../../quries/operations");
const Auth = require("../../common/authenticate");
const functions = require("../../common/functions");
const Model = require("../../models");




async function createAdmin(req, res, body, next) {
  
  const counterFilter = { counterKey: "ALL" };
  const countItem = await Query.getAllItemsByQueryKey( Model.Counter, counterFilter);

  try {
    let Item = {
      ...body,
      id: uuidv4(),
      serialNo: countItem.admin,
      role: "ADMIN", // SUPER_ADMIN ,ADMIN
      adminId: "678678", // SUPER_ADMIN ,ADMIN
      accessToken: "dtreg", // Consider generating a real token here
      ipAddress: req.ip,
    };

    if (body?.password && body?.password_2) Item.role = "SUPER_ADMIN";

    const Items = await Query.insertItem(Model.Admin, Item);

    countItem.admin += 1;
    await countItem.save();

    return res.success("ACCOUNT_CREATED_SUCCESSFULLY", Item);
  } catch (error) {
    console.log({ error });
    next(error);
  }
}

module.exports.register = async (req, res, next) => {
  const { userName, full_name, password, password_2 } = req.body;
  // Fetch admin data based on userName

  if (!userName || userName.length < 3 || userName.length > 20) {
    return res.error(400, "Username must be between 3 and 20 characters.");
  }

  const usernameRegex = /^[a-zA-Z0-9_]+$/;
  if (!usernameRegex.test(userName)) {
    return res.error(
      400,
      "Username can only contain letters, numbers, and underscores."
    );
  }

  const adminData = await Query.getAllItemsByQueryKey(Model.Admin, {
    userName,
  });

  // Check if admin account exists
  if (adminData) return res.error(400, "Account Already  Exist");
  let obj = {
    userName,
    full_name,
    password: password && (await Auth.setPassword(password)),
    password_2: password_2 && (await Auth.setPassword(password_2)),
  };

  await createAdmin(req, res, obj, next);
};

module.exports.login = async (req, res, next) => {
  const { userName, full_name, password, password_2 } = req.body;

  try {
    // Fetch admin data based on userName

    const Items = await Query.getAllItemsByQueryKey(Model.Admin, { userName });

    // Check if admin account exists
    if (!Items) return res.error(400, "Account Not Found");

    const adminDoc = Items;

    // Validate password requirements for SUPER_ADMIN role
    if (adminDoc.role === "SUPER_ADMIN" && (!password || !password_2)) {
      throw new Error("Both passwords are required for SUPER_ADMIN");
    }

    // Authenticate passwords if provided
    if (password) await Auth.authenticatePassword(password, adminDoc.password);
    if (password_2) await Auth.authenticatePassword(password_2, adminDoc.password_2);

    // Check if account is blocked
    if (adminDoc.isBlocked)
      return res.error(400, "Your account have been blocked");
    if (adminDoc.isDeleted)
      return res.error(400, "Your account have been deleted");

    const accessToken = await Auth.getToken({ id: adminDoc.id });

    adminDoc.accessToken = accessToken;
    adminDoc.full_name = full_name;
    adminDoc.lastLogin = new Date().toISOString();

    await adminDoc.save();

    // const updatedItem = await Query.insertItem(Table.Admin, adminDoc);
    return res.success("Login successful", adminDoc);
  } catch (error) {
    next(error);
  }
};

module.exports.logout = async (req, res, next) => {
  try {
    const Item = await Query.getItemById(Model.Admin, req.admin.id);
    if (!Item) throw new Error("Account does not exit ");

    Item.accessToken = "";
    await Item.save();

    return res.success("Logout successfully");
  } catch (error) {
    console.error("Login error:", error);
    next(error);
  }
};

module.exports.getProfile = async (req, res, next) => {
  try {
    const id = req.admin.id ?? req.params.id;
    const Items = await Query.getItemById(Model.Admin, id);

    if (!Items) return res.error(400, " account does not exist");

    return res.success("successfully", Items);
  } catch (error) {
    next(error);
  }
};

module.exports.changePassword = async (req, res, next) => {
  const { userName, password, newPassword, password_2, newPassword_2 } =
    req.body;
  console.log(
    "bakcend",
    userName,
    password,
    newPassword,
    password_2,
    newPassword_2
  );
  try {
    if (!userName || !password) {
      throw new Error("Inputs are required");
    }

    // Fetch admin data based on userName
    const adminData = await Query.getAllItemsByQueryKey(Model.Admin, {
      userName,
    });

    // Check if admin account exists
    if (!adminData) return res.error(400, "Account does not exit ");

    const adminDoc = adminData;

    // Validate password requirements for SUPER_ADMIN role
    if (adminDoc.role === "SUPER_ADMIN" && (!password || !password_2)) {
      throw new Error("Both passwords are required for SUPER_ADMIN");
    }

    // Check if account is blocked
    if (adminDoc.isBlocked) return res.error(400, "Account has been blocked");
    if (adminDoc.isDeleted) return res.error(400, "Account has been deleted");

    // Authenticate passwords if provided
    if (password) {
      if (!newPassword) throw new Error("New password is require  ");
      if (password == newPassword)
        throw new Error("password and newPassword could  not be same");
      await Auth.authenticatePassword(password, adminDoc.password);
      adminDoc.password = await Auth.setPassword(newPassword);
    }

    if (password_2) {
      if (!newPassword_2) throw new Error("New password is require  ");
      if (password_2 == newPassword_2)
        throw new Error("password and new Password could  not be same");
      await Auth.authenticatePassword(password_2, adminDoc.password_2);
      adminDoc.password_2 = await Auth.setPassword(newPassword_2);
    }

    await adminDoc.save();

    return res.success("password changes  successfully", true);
  } catch (error) {
    console.error("Login error:", error);
    next(error);
  }
};

module.exports.getUserProfile = async (req, res, next) => {
  try {
    const { id } = req.params;
    const Items = await Query.getItemById(Model.User, id);

    // console.log({ Items })

    if (!Items) return res.error(400, " account does not exist");

    return res.success("successfully", Items);
  } catch (error) {
    next(error);
  }
};

module.exports.getAllUser = async (req, res, next) => {
  try {
    let filterObj = { isDeleted: false, isBlocked: false };

    const { exclusiveStartKey, page, limit = 3 } = req.query;

    const Items = await Query.getAllDataWithPagination(
      Model.User,
      filterObj,
      {},
      limit,
      page,
      exclusiveStartKey
    );

    if (Items.length === 0) throw new Error("No record  found");
    console.log(`item by page number ${page} ========== `, Items, Items.length);
    return res.success("successfully", Items);
  } catch (error) {
    next(error);
  }
};

module.exports.get_aadhar_card = async (req, res, next) => {
  try {
    const { id } = req.query;
    const Items = await Query.getItemById(Model.User, id);
    console.log("get_data========", Items);
    return res.success("GET ALL DATA FROM USER", Items);
  } catch (error) {
    next(error);
  }
};
