module.exports = {
  User: require("./User"),
  Admin: require("./Admin"),
  Counter: require("./Counter"),
  UserFile:require("./userfileupload"),

};
