
const { v4: uuidv4 } = require('uuid');
const Query = require("../../quries/operations");
const Model = require("../../models");


 
const counterFilter = { counterKey: "ALL" }


module.exports.create = async (req, res, next) => {

  try {

    const Items = await Query.getAllItemsByQueryKey(Model.Counter, counterFilter)
    if (Items) return res.error(400, "Item already have ")

    let obj = {
      id: uuidv4(),
      user: 1,
      admin: 1,
      order: 1,
      transaction: 1
    }

    const insert = await Query.insertItem(Model.Counter, obj)
    return res.success("count added successfully ", insert)

  } catch (error) {
    console.error('Login error:', error);
    next(error)
  }
}


module.exports.get = async (req, res, next) => {

  try {
    const Items = await Query.getAllItemsByQueryKey(Model.Counter, counterFilter)
    if (!Items) return res.error(400, "No record Found")
    return res.success("successfully", Items)

  } catch (error) {
    next(error)
  }
}


