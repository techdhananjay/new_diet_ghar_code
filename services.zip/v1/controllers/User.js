
const { v4: uuidv4 } = require("uuid");


const Query = require("../../quries/operations");
const Auth = require("../../common/authenticate");
const functions = require("../../common/functions");

const service = require("../../services");
const Model = require("../../models");







const sendsms = async (body, otp) => {
  const { email, phone } = body;

  // await service.SendPhoneOtp.sendotp(phone, otp)

  let sendMsg = false;
  if (email && !sendMsg) {
    console.log("email message");
    let payload = {
      to: email,
      title: "Verify your account",
      message: `Your verification code is ${otp}`,
    };

    await service.EmailService.send(payload);
    sendMsg = true;
  } else if (phone && !sendMsg) {
    console.log("phone message");
    await service.SendPhoneOtp.sendotp(phone, otp);
    sendMsg = true;
  }
};



module.exports.createUser = async (req, res, body, OTP) => {

  const counterFilter = { counterKey: "ALL" }

  const countItem = await Query.getAllItemsByQueryKey(Model.Counter, counterFilter)


  try {
    let Item = {
      ...body,
      id: uuidv4(),
      serialNo: countItem.user,
      ipAddress: req.ip,
      otp: Number(OTP),
    };

    Item.accessToken = await Auth.getToken({ id: Item.id });

    await Query.insertItem(Model.User, Item)

    countItem.user += 1
    await countItem.save()

    // await sendsms(body?.email ? { email: body?.email } : { phone: body?.phone }, Number(OTP));

    return res.success("ACCOUNT_CREATED_SUCCESSFULLY", Item);
  } catch (error) {
    console.log({ error });
    return res.error(400, "something went wrong during user creating time ");
  }
};


module.exports.login = async (req, res, next) => {
  const { email, phone, password, full_name, deviceAddress, deviceType } = req.body;
  const filter = email ? { email: email.toLowerCase() } : { phone };

  const OTP = await functions.generateNumber(6);

  let insertObj = { email: email.toLowerCase(), phone, password, full_name, deviceAddress, deviceType }


  try {
    const Items = await Query.getAllItemsByQueryKey(Model.User, filter);
    if (Items) {
      const doc = Items;

      if (!password) return res.error(400, "password is required");

      if (doc.isBlocked) return res.error(400, "Your account have been blocked");
      if (doc.isDeleted) return res.error(400, "Your account have been deleted");

      if (password) await Auth.authenticatePassword(password, doc?.password);

      const accessToken = await Auth.getToken({ id: doc.id });
      doc.accessToken = accessToken;
      doc.otp = Number(OTP);
      doc.isOTPVerify = false

      if (full_name) doc.full_name = full_name
      if (deviceAddress) doc.deviceAddress = deviceAddress
      if (deviceType) doc.deviceType = deviceType

      await doc.save();
      await sendsms(filter, Number(OTP));

      return res.success("Login successful", doc);
    } else {
      insertObj.password = await Auth.setPassword(password)
      await this.createUser(req, res, insertObj, Number(OTP));
      // await sendsms(filter, Number(OTP));
    }
  } catch (error) {
    console.error("Error querying user:", error);
    next(error);
  }
};



module.exports.verifyOtp = async (req, res, next) => {
  try {
    const { email, phone, otp } = req.body;
    const filter = email ? { email: email.toLowerCase() } : { phone };

    const Items = await Query.getAllItemsByQueryKey(Model.User, filter);

    if (!Items || Items.otp !== otp) {
      return res.error(400, "Invalid OTP or account does not exist");
    }

    Items.isOTPVerify = true;
    await Items.save();
    return res.success("OTP Verified", Items);
  } catch (error) {
    next(error);
  }
};

module.exports.sendOtp = async (req, res, next) => {
  try {
    const { email, phone } = req.body;
    const filter = email ? { email } : { phone };

    const Items = await Query.getAllItemsByQueryKey(Model.User, filter);

    if (!Items) return res.error(400, "account does not exist");

    const OTP = await functions.generateNumber(6);
    const checkPin = Items.isPinCreated;

    Items.otp = Number(OTP);
    // if (!checkPin) Items.isOTPVerify = false;
    // if (checkPin) Items.isPinCreated = false;

    await Items.save(Items);
    await sendsms(filter, Number(OTP));

    return res.success("otp sended ");
  } catch (error) {
    next(error);
  }
};

module.exports.logout = async (req, res, next) => {
  try {
    const Item = await Query.getItemById(Model.User, req.user.id);
    if (!Item) throw new Error("Account does not exit ");

    Item.accessToken = "";

    await Item.save();

    return res.success("Logout successfully");
  } catch (error) {
    console.error("Login error:", error);
    next(error);
  }
};

module.exports.getProfile = async (req, res, next) => {
  try {
    const Items = await Query.getItemByIdExpecificElement(Model.User, req.user.id);
    if (!Items) {
      return res.error(400, " account does not exist");
    }
    console.log('idtresmmmm=======', Items)
    return res.success("successfully", Items);
  } catch (error) {
    next(error);
  }
};

module.exports.getAllUser = async (req, res, next) => {
  try {
    let filterObj = { isDeleted: false, isBlocked: false };


    const { exclusiveStartKey, page = 1, limit = 10, searchQuery } = req.query


    // const Itemss = await Query.findUsersByMultipleFieldsAndConditions(Model.User,searchQuery)

    // console.log("Items =>",Itemss)
    // return 

    let searchInput = {}
    // const regex = new RegExp(searchQuery, "i");

    if (searchQuery) {
      searchInput = {
        full_name: searchQuery,
        // email: searchQuery,
        // address:searchQuery,
      }
    }

    // return 
    const Items = await Query.getAllDataWithPagination(
      Model.User,
      filterObj,
      searchInput,
      Number(limit),
      Number(page),
      exclusiveStartKey
    );

    if (Items.length === 0) throw new Error("No record  found");

    return res.success("successfully", Items);
  } catch (error) {
    next(error);
  }
};

