const Joi = require("joi").defaults((schema) => {
  switch (schema.type) {
    case "string":
      return schema.replace(/\s+/, " ");
    default:
      return schema;
  }
});

Joi.objectId = () => Joi.string().pattern(/^[0-9a-f]{24}$/, "valid ObjectId");

module.exports.identify = Joi.object({
  id: Joi.objectId().required(),
});

module.exports.register = Joi.object({
  firstName: Joi.string().required(),
  lastName: Joi.string().optional(),
  confirmPassword: Joi.string().optional(),
  phoneNo: Joi.number().optional(),
  username: Joi.string().optional(),
  email: Joi.string().email().required(),
  password: Joi.string().required(),
  city: Joi.string().optional(),
  deviceType: Joi.string().allow("WEB", "IOS", "ANDROID").optional(),
  userType: Joi.string().allow("USER", "ADMIN").optional(),
  deviceToken: Joi.string().optional(),
}).or("phoneNo", "email", "countryCodephoneNo");



module.exports.login = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
  deviceType: Joi.string().allow("WEB", "IOS", "ANDROID").optional(),
  deviceToken: Joi.string().optional(),
  isAdmin: Joi.boolean().optional(),
});
