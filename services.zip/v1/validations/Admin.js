const Model = require('../../models/mongo');
const Joi = require("joi").defaults((schema) => {
  switch (schema.type) {
    case "string":
      return schema.replace(/\s+/, " ");
    default:
      return schema;
  }
});

Joi.objectId = () => Joi.string().pattern(/^[0-9a-f]{24}$/, "valid ObjectId");

module.exports.identify = Joi.object({
  id: Joi.objectId().required(),
});

module.exports.register = Joi.object({
  email: Joi.string().email().optional(),
  phoneNo: Joi.string()
    .regex(/^[0-9]{5,}$/)
    .optional(),
  dialCode: Joi.string()
    .regex(/^\+?[0-9]{1,}$/)
    .optional(),
  deviceType: Joi.string().allow("WEB", "IOS", "ANDROID").optional(),
  deviceToken: Joi.string().optional(),
  password: Joi.string().required(),
})
  .or("phoneNo", "email")
  .with("phoneNo", "dialCode");

module.exports.registerVender = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
  name: Joi.string().required(),
  phoneNo: Joi.number().optional(),
  dialCode: Joi.number().optional()
});

module.exports.login = Joi.object({
  email: Joi.string().email().optional(),
  phoneNo: Joi.string()
    .regex(/^[0-9]{5,}$/)
    .optional(),
  dialCode: Joi.string()
    .regex(/^\+?[0-9]{1,}$/)
    .optional(),
  password: Joi.string().required(),
  deviceType: Joi.string().allow("WEB", "IOS", "ANDROID").optional(),
  deviceToken: Joi.string().optional(),
})
  .or("phoneNo", "email")
  .with("phoneNo", "dialCode");









