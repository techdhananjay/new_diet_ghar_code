module.exports = {
    User: require("./User"),
    Admin: require("./Admin"),
  
};





